# y_dumpamx

```pawn
#include <YSI_Storage\y_dumpamx>

public OnScriptInit()
{
	// Dump the running script to a file.
	DumpAMX_Write("output.amx");
}
```

